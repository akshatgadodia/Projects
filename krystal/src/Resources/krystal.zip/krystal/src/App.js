import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque reprehenderit vero accusantium fuga, ullam, aliquam hic placeat, aspernatur nisi deleniti saepe. Tempora nihil provident expedita perspiciatis numquam, suscipit optio architecto.</p>
    </div>
  );
}

export default App;
